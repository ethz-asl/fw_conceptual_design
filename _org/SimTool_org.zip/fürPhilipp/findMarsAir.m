function [rho,mu]=findMarsAir(h,T_ground)

% http://www.grc.nasa.gov/WWW/K-12/airplane/atmosmrm.html

if h<7000
    T = T_ground - 0.000998 * h;
    p = .699 * exp(-0.00009 * h);
else
    T = (-23.4+273.1) - 0.00222 * h;
    p = .699 * exp(-0.00009 * h);
end

% Dynamic air viscosity
rho = p / (.1921 *T);
mu  = 13e-6; %[Pa*s]

end