function out=solarMarsDay(in)

%[1] http://ccar.colorado.edu/asen5050/projects/projects_2001/benoit/solar_irra
%    diance_on_mars.htm
%[2] Applebaum

L_s         =   in(1)/180*pi; % [rad] areocentric longitude of sun
latitude    =   in(2)/180*pi; % [rad]
%altitude    =   in(4); % [m]

tau=0.3; % [-] optical depth estimate 0.5 is not conservative!
S_0=1371/(1.523679*(1-0.093315^2)/(1+0.093315*cos(L_s-248/180*pi)))^2;
delta=asin(sin(25.2/180*pi)*sin(L_s));
cos_arg=-sin(latitude)*sin(delta)/(cos(latitude)*cos(delta));
if(cos_arg>1)
    cos_arg=1; % this means no sun all day long
else if (cos_arg<-1)
    cos_arg=-1; % this means no sun all day long
    end
end
out(2)=acos(cos_arg)/(pi/88775);
H=(pi/88775)*out(2);
%out(1)=(S_0*exp(-tau)/pi)*(sin(latitude)*sin(delta)*H+cos(latitude)*cos(delta)*sin(H));
%use numeric integration
N=100;
h=0:H/N:H;
cos_z = max((sin(latitude)*sin(delta)+cos(latitude)*cos(delta)*cos(h)),0);%cos of zenith angle
S = S_0*cos_z;
out(1)=trapz(S.*exp(-tau./(cos_z)))/(pi*(N+1)); % Beer's law