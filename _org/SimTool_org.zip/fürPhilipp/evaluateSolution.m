%==========================================================================
%=== Global Design of senseSoar Airplane
%=== Find the optimal plane for a given setting and evaluate it
%=== Stefan Leutenegger
%=== 05/2009
%==========================================================================

function [performance,polar,masses] ...
 = evaluateSolution(b,AR,m_bat,payload,environment,parameters)

% Input processing
% ================



% set the masses of the various components
% ========================================

% Solar module
m_solar = b*b/AR*...
    (parameters.solar.k_sc+parameters.solar.k_enc);

% MPPT
I_max = 1200; %[W/m^2]
m_mppt = parameters.solar.k_mppt*I_max*b*b/AR ...
	*parameters.solar.n_sc*parameters.solar.n_cbr;

% total point mass
m_central = m_mppt+payload.mass+parameters.avionics.mass...
    +(1-parameters.batt.distr)*m_bat;

% total distributed mass
m_distr = m_solar+m_bat*parameters.batt.distr;


% Automatic Preliminary Design (S. Leutenegger / M. Jabas)
% ========================================================
if(parameters.structure.shell==1)
    [m_struct,masses,thicknesses,velocities,polar]=StructureDesigner(b,AR,...
        m_central,m_distr,parameters.propulsion.number,environment.usemars);
else
    [m_struct,masses,thicknesses,velocities,polar]=StructureDesignerRibWing(b,AR,...
        m_central,m_distr,parameters.propulsion.number,environment.usemars);
end
masses.m_struct=m_struct;

% Now simulate the course of a day
% ================================

% Calculate the "Performance" in terms of endurance/range(speed) or 
% excess time, if continuos flight is possible

batt.e_density=parameters.batt.k_bat/3600;
batt.m=m_bat;
batt.n_chrg=parameters.batt.n_chrg;
batt.n_dchrg=parameters.batt.n_dchrg;

if (parameters.evaluation.findalt~=1)
    [performance.t_excess, performance.t_endurance] = performanceEvaluator_new(...
        parameters.evaluation.clmb,polar,b^2/AR,b,...
        masses.m_prop+m_distr+m_central+m_struct-m_bat,batt,...
        parameters.propulsion.n_ctrl*parameters.propulsion.n_mot...
        *parameters.propulsion.n_grb*parameters.propulsion.n_plr,...
        parameters.solar.n_sc*parameters.solar.n_cbr...
        *parameters.solar.n_mppt*b^2/AR,...
        payload.power+parameters.avionics.power,environment.h,environment);
else
    performance.t_excess=0;
    environment.h=0;
    hU=30000; % max
    hL=0; % min
    h=hL;
    delta_h=hU-hL;
    [performance.t_excess, performance.t_endurance] = performanceEvaluator_new(...
        parameters.evaluation.clmb,polar,b^2/AR,b,...
        masses.m_prop+m_distr+m_central+m_struct-m_bat,batt,...
        parameters.propulsion.n_ctrl*parameters.propulsion.n_mot...
        *parameters.propulsion.n_grb*parameters.propulsion.n_plr,...
        parameters.solar.n_sc*parameters.solar.n_cbr...
        *parameters.solar.n_mppt*b^2/AR,...
        payload.power+parameters.avionics.power,0,environment);
    if isnan(performance.t_excess) == 0
        while (delta_h>1)
            h=(hU+hL)/2;
            environment.h=h;
            [performance.t_excess, performance.t_endurance] = performanceEvaluator_new(...
                parameters.evaluation.clmb,polar,b^2/AR,b,...
                masses.m_prop+m_distr+m_central+m_struct-m_bat,batt,...
                parameters.propulsion.n_ctrl*parameters.propulsion.n_mot...
                *parameters.propulsion.n_grb*parameters.propulsion.n_plr,...
                parameters.solar.n_sc*parameters.solar.n_cbr...
                *parameters.solar.n_mppt*b^2/AR,...
                payload.power+parameters.avionics.power,h,environment);
            if isnan(performance.t_excess)==1
                hU=h;
            else
                
                hL=h;
            end
            %disp([hU, hL])
            delta_h=hU-hL;
            %disp(environment.h);
        end
    end
    performance.h=h;
end

%performance.P_elec_tot = P_elec_tot;
%performance.P_level = P_level;
g=parameters.physics.g;
if(environment.usemars==1)
    [rho,mu] = findMarsAir(environment.h,environment.T_ground);
else
    [rho,mu] = findAir(environment.h,environment.T_ground);
end
v_tmax=sqrt(2*(m_distr+m_central+m_struct)*g/(rho*b^2/AR*mean(polar.c_L_cn)));
%refine iteratively
delta_v_tmax=1;
while abs(delta_v_tmax)>0.01
    Re=min([rho*b/AR*v_tmax/mu,polar.ReList(length(polar.ReList))]);
    v_tmax_old = v_tmax;
    CL = interp1(log(polar.ReList),polar.c_L_cn,log(Re));
    v_tmax = sqrt((m_distr+m_central+m_struct)*g/(0.5*rho*b^2/AR*CL)); % logarithmic interp.
    delta_v_tmax=(v_tmax-v_tmax_old)/v_tmax;
end
CL = interp1(log(polar.ReList),polar.c_L_gr,log(Re));
v_rmax=sqrt(2*(m_distr+m_central+m_struct)*g/(rho*b^2/AR*CL));
%refine iteratively
delta_v_rmax=1;
while abs(delta_v_rmax)>0.01
    Re=min([rho*b/AR*v_rmax/mu,polar.ReList(length(polar.ReList))]);
    v_rmax_old = v_rmax;
    CL = interp1(log(polar.ReList),polar.c_L_gr,log(Re));
    v_rmax = sqrt((m_distr+m_central+m_struct)*g/(0.5*rho*b^2/AR*CL)); % logarithmic interp.
    delta_v_rmax=(v_rmax-v_rmax_old)/v_rmax;
end

performance.v_rmax = v_rmax;% speed for maximum range
performance.v_tmax = v_tmax; % speed for maximized flight time
%performance.max_range = 
%performance.range_at_tmax = 