function out=irradianceMars(in)

t           =   in(1); % [s] after noon
L_s         =   in(2)/180*pi; % [rad] areocentric longitude of sun
latitude    =   in(3)/180*pi; % [dad]
%altitude    =   in(4); % [m]

tau=0.3; % [-] optical depth estimate 0.5 is not conservative!
S_0=1371/(1.523679*(1-0.093315^2)/(1+0.093315*cos(L_s-248/180*pi)))^2;
delta=asin(sin(25.2/180*pi)*sin(L_s));
cos_z = max((sin(latitude)*sin(delta)+cos(latitude)*cos(delta)*cos(2*pi*t/88775)),0);%cos of zenith angle
S = S_0*cos_z;
out=S*exp(-tau/(cos_z)); % Beer's law