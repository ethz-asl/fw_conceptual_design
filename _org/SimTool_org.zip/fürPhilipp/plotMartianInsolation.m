% plot the martian insolation

step_lat = 1; %[deg]
step_Ls = 1; %[deg]

P_mean = zeros(2*90/step_lat+1,360/step_Ls+1);
T_day = zeros(2*90/step_lat+1,360/step_Ls+1);
lat_array = -90:step_lat:90;
Ls_array = 0:step_Ls:360;
out=[0,0];
i=0;
j=0;

h = waitbar(0,'Please wait...');

for lat=lat_array
    j=0;
    i=i+1;
    for Ls=Ls_array
        j=j+1;
        out=solarMarsDay([Ls,lat]);
        P_mean(i,j)=out(1);
        T_day(i,j)=(out(2))/3600;
    end
    waitbar(i/length(lat_array))
end

close(h)

figure(1);
subplot(2,1,1);
v1=0:10:160;
contourf(Ls_array,lat_array,P_mean,0:80/255:160,'LineStyle','None');
title('Mean daily vertical irradiance at surface [W/m^2]');
xlabel('Areocentric longitude [deg]');
ylabel('Geographic latitude [deg]');
colormap hot
colorbar('YTick',v1);
set(gca,'XTick',0:45:360)
set(gca,'YTick',-90:45:90)
subplot(2,1,2);
v2=0:3:24;
contourf(Ls_array,lat_array,T_day,0:((88775/3600)/255):(88775/3600),'LineStyle','None');
title('Day time [h]');
xlabel('Areocentric longitude [deg]');
ylabel('Geographic latitude [deg]');
colorbar('YTick',v2);
set(gca,'XTick',0:45:360)
set(gca,'YTick',-90:45:90)

% comparison:
delta_t=60;
t_array=0:delta_t:24*3600;
irr=zeros(length(t_array),1);
i=0;
for t=t_array
    i=i+1;
    out=solar_radiation_on_surface2(0,0,t,30.5*6+21,...
        37.34,0, 20,environment.albedo);
    irr(i)=out(1);
end
irr_mean=trapz(irr)/length(irr);
disp('Mean insolation in San Jos�, CA [W/m^2]:')
disp(irr_mean)