% evaluate small uav
clear all;

b=3;
AR=12;
lat_array=0:1:90;

initParameters;

% Editable Section:
% =================

% Set environment, payload and airfoil
environment.month = 12;
environment.day = 21;
environment.lat = 37;
environment.h = 700;
environment.T_ground = 300;
%%environment.lat = 47;
environment.albedo = 0.2;
environment.clearness = 1;
payload.mass = 0.6;%0.2;%0.722;
payload.power = 4;%1.7;%18.4;

% Change some parameters
parameters.propulsion.number  =  2;        % Number of propulsion units [-]
parameters.structure.shell    =  1;        % 1 for shell wing, 0 for rib wing
parameters.evaluation.clmb    =  1;        % 1 to allow altitude changes
parameters.evaluation.findalt =  0;        % if 1, it finds the maximum
                                           % altitude for eternal flight
                                           
%this finds the design maximum m_bat
% m_bat_array=0:0.01:4;  
% exc=zeros(size(m_bat_array));                                       
% for k=1:length(m_bat_array)
%     m_bat=m_bat_array(k);
%     [performance,polar,masses] = ...
%         evaluateSolution(b,AR,m_bat,payload,environment,parameters);
%     exc(k)=performance.t_excess;
% end
% [exc_max,k_exc_max]=max(exc);
% m_bat=m_bat_array(k_exc_max);
m_bat=2.35;
m_bat_array=0.5:0.05:m_bat;

%--------------------------------------------------------------

% Input processing
% ================

[rho,mu] = findAir(environment.h,environment.T_ground);

% set the masses of the various components
% ========================================

% Solar module
m_solar = b*b/AR*...
    (parameters.solar.k_sc+parameters.solar.k_enc);

% MPPT
I_max = 1200; %[W/m^2]
m_mppt = parameters.solar.k_mppt*I_max*b*b/AR ...
	*parameters.solar.n_sc*parameters.solar.n_cbr;

% total point mass
m_central = m_mppt+payload.mass+parameters.avionics.mass...
    +(1-parameters.batt.distr)*m_bat;

% total distributed mass
m_distr = m_solar+m_bat*parameters.batt.distr;


% Automatic Preliminary Design (S. Leutenegger / M. Jabas)
% ========================================================
if(parameters.structure.shell==1)
    [m_struct,masses,thicknesses,velocities,polar]=StructureDesigner(b,AR,...
        m_central,m_distr,parameters.propulsion.number);
else
    [m_struct,masses,thicknesses,velocities,polar]=StructureDesignerRibWing(b,AR,...
        m_central,m_distr,parameters.propulsion.number);
end
masses.m_struct=m_struct;

% Now simulate the course of a day
% ================================

% Calculate the "Performance" in terms of endurance/range(speed) or 
% excess time, if continuos flight is possible

batt.e_density=parameters.batt.k_bat/3600;
batt.n_chrg=parameters.batt.n_chrg;
batt.n_dchrg=parameters.batt.n_dchrg;

excess=zeros(length(lat_array),1);
endurance=zeros(length(lat_array),1);
m_exc=zeros(length(lat_array),1);
m_end=zeros(length(lat_array),1);
for i=1:length(lat_array)
    environment.lat=lat_array(i);
    excess_tmp=zeros(length(m_bat),1);
    endurance_tmp=zeros(length(m_bat),1);
    for j=1:length(m_bat_array)
        m_bat=m_bat_array(j);
        batt.m=m_bat;
        m_central = m_mppt+payload.mass+parameters.avionics.mass...
            +(1-parameters.batt.distr)*m_bat;
        m_distr = m_solar+m_bat*parameters.batt.distr;
        [performance.t_excess, performance.t_endurance] = performanceEvaluator(...
            parameters.evaluation.clmb,polar,b^2/AR,b,...
            masses.m_prop+m_distr+m_central+m_struct-m_bat,batt,...
            parameters.propulsion.n_ctrl*parameters.propulsion.n_mot...
            *parameters.propulsion.n_grb*parameters.propulsion.n_plr,...
            parameters.solar.n_sc*parameters.solar.n_cbr...
            *parameters.solar.n_mppt*b^2/AR,...
            payload.power+parameters.avionics.power,environment.h,environment);
        g=parameters.physics.g;
        [rho,mu] = findAir(environment.h,environment.T_ground);
        v_tmax=sqrt(2*(m_distr+m_central+m_struct)*g/(rho*b^2/AR*mean(polar.c_L_cn)));
        %refine iteratively
        delta_v_tmax=1;
        while abs(delta_v_tmax)>0.01
            Re=min([rho*b/AR*v_tmax/mu,polar.ReList(length(polar.ReList))]);
            v_tmax_old = v_tmax;
            CL = interp1(log(polar.ReList),polar.c_L_cn,log(Re));
            v_tmax = sqrt((m_distr+m_central+m_struct)*g/(0.5*rho*b^2/AR*CL)); % logarithmic interp.
            delta_v_tmax=(v_tmax-v_tmax_old)/v_tmax;
        end
        CL = interp1(log(polar.ReList),polar.c_L_gr,log(Re));
        v_rmax=sqrt(2*(m_distr+m_central+m_struct)*g/(rho*b^2/AR*CL));
        %refine iteratively
        delta_v_rmax=1;
        while abs(delta_v_rmax)>0.01
            Re=min([rho*b/AR*v_rmax/mu,polar.ReList(length(polar.ReList))]);
            v_rmax_old = v_rmax;
            CL = interp1(log(polar.ReList),polar.c_L_gr,log(Re));
            v_rmax = sqrt((m_distr+m_central+m_struct)*g/(0.5*rho*b^2/AR*CL)); % logarithmic interp.
            delta_v_rmax=(v_rmax-v_rmax_old)/v_rmax;
        end

        performance.v_rmax = v_rmax;% speed for maximum range
        performance.v_tmax = v_tmax; % speed for maximized flight time
        
        excess_tmp(j)=performance.t_excess;
        endurance_tmp(j)=performance.t_endurance;
    end
    [excess(i),j_exc]=max(excess_tmp);
    if(isnan(excess(i)))
        [endurance(i),j_end]=max(endurance_tmp);
        m_exc(i)=NaN;
        m_end(i)=m_bat_array(j_end);
    else
        endurance(i)=NaN;
        m_exc(i)=m_bat_array(j_exc);
        m_end(i)=NaN;
    end
    disp(environment.lat);
end

store_winter_var = [excess, endurance, m_exc, m_end];
save store_winter_var;

load store_summer_var
load store_summer_const
load store_autumn_var
load store_autumn_const
load store_winter_var
load store_winter_const
subplot(4,3,1)
plot(lat_array,store_summer_var(:,1),'r','LineWidth',1.5); hold on;
plot(lat_array,store_summer_const(:,1));
axis([0,90,0,10])
ylabel('Excess time [h]')
title('Summer solstice')
subplot(4,3,4)
plot(lat_array,store_summer_var(:,2),':r','LineWidth',1.5); hold on;
plot(lat_array,store_summer_const(:,2),':');
axis([0,90,0,40])
ylabel('Endurance [h]')
subplot(4,3,7)
plot(lat_array,store_summer_var(:,3),'r','LineWidth',1.5); hold on;
plot(lat_array,store_summer_var(:,4),':r','LineWidth',1.5); hold on;
plot(lat_array,store_summer_const(:,3)); hold on;
plot(lat_array,store_summer_const(:,4),':'); hold on;
axis([0,90,0,2.4])
ylabel('Battery mass [kg]')
xlabel('Latitude [�N]')
subplot(4,3,2)
plot(lat_array,store_autumn_var(:,1),'r','LineWidth',1.5); hold on;
plot(lat_array,store_autumn_const(:,1));
ylabel('Excess time [h]')
title('Autumnial equinox')
axis([0,90,0,10])
subplot(4,3,5)
plot(lat_array,store_autumn_var(:,2),':r','LineWidth',1.5); hold on;
plot(lat_array,store_autumn_const(:,2),':');
axis([0,90,0,40])
ylabel('Endurance [h]')
subplot(4,3,8)
plot(lat_array,store_autumn_var(:,3),'r','LineWidth',1.5); hold on;
plot(lat_array,store_autumn_var(:,4),':r','LineWidth',1.5); hold on;
plot(lat_array,store_autumn_const(:,3)); hold on;
plot(lat_array,store_autumn_const(:,4),':'); hold on;
axis([0,90,0,2.4])
ylabel('Battery mass [kg]')
xlabel('Latitude [�N]')
subplot(4,3,3)
plot(lat_array,store_winter_var(:,1),'r','LineWidth',1.5); hold on;
plot(lat_array,store_winter_const(:,1));
ylabel('Excess time [h]')
title('Winter solstice')
axis([0,90,0,10])
subplot(4,3,6)
plot(lat_array,store_winter_var(:,2),':r','LineWidth',1.5); hold on;
plot(lat_array,store_winter_const(:,2),':');
axis([0,90,0,40])
ylabel('Endurance [h]')
subplot(4,3,9)
plot(lat_array,store_winter_var(:,3),'r','LineWidth',1.5); hold on;
plot(lat_array,store_winter_var(:,4),':r','LineWidth',1.5); hold on;
plot(lat_array,store_winter_const(:,3)); hold on;
plot(lat_array,store_winter_const(:,4),':'); hold on;
axis([0,90,0,2.4])
ylabel('Battery mass [kg]')
xlabel('Latitude [�N]')
legend('Altitude variation allowed: sustained flight','Altitude variation allowed: maximized endurance',...
    'Const. altitude: sustained flight','Const. altitude: maximized endurance')