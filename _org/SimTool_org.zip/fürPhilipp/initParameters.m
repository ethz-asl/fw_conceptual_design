%==========================================================================
%=== Global Design of senseSoar Airplane
%=== Initialization of  Parameters
%=== Stefan Leutenegger
%=== 05/2009
%==========================================================================

clear parameters;

%--- ADAPT THESE PARAMETERS -----------------------------------------------

%=== Propulsion Group =====================================================
parameters.propulsion.k_prop  =  0.0011;   % Mass/Power [kg/W]
parameters.propulsion.n_ctrl  =  0.95;     % Eff. of motor controller [-]
parameters.propulsion.n_mot   =  0.8;      % Efficiency of motor [-]
parameters.propulsion.n_grb   =  0.97;     % Efficiency of gearbox [-]
parameters.propulsion.n_plr   =  0.8;      % Efficiency of propeller [-]
parameters.propulsion.number  =  2;        % Number of propulsion units [-]

%=== Battery and Step-down Converter ======================================
parameters.batt.n_chrg        =  0.95;     % Eff. of charge process [-]
parameters.batt.n_dchrg       =  0.95;     % Eff. of discharge process [-]
parameters.batt.n_bec         =  0.65;     % Eff. of bec (5V stepdown) [-]
parameters.batt.k_bat         =  240*3600; % Energy density of LiIon [J/Kg]
parameters.batt.distr         =  1;        % Distributed battery mass? 1/0

%=== Solar cells ==========================================================
parameters.solar.k_sc         =  0.32;     % Mass density of sc [Kg/m2]
parameters.solar.k_enc        =  0.1;      % Mass dens. of encaps. [Kg/m2]
parameters.solar.k_mppt       =  1/2368;   % Mass/Power of mppt [kg/W]
parameters.solar.n_sc         =  0.19;     % Efficiency of solar cells [-]
parameters.solar.n_cbr        =  0.9;      % Eff. of cambered conf. [-]
parameters.solar.n_mppt       =  0.95;     % Efficiency of mppt [-]

%==== Avionics ============================================================
parameters.avionics.mass      =  0.05;     % Mass of contr./electr. [kg]
parameters.avionics.power     =  1.5;      % Power required for control [W]

%==== Structure ===========================================================
parameters.structure.shell    =  1;        % 1 for shell wing, 0 for rib wing


%--------------------------------------------------------------------------

%=== Physics ==============================================================
parameters.physics.g          = 9.81;      % Earth Acceleration [m/s^2]

%=== Performance evaluation
parameters.evaluation.clmb    = 1;         % 1 to allow altitude changes
parameters.evaluation.findalt = 0;         % if 1, it finds the maximum
                                           % altitude for eternal flight
