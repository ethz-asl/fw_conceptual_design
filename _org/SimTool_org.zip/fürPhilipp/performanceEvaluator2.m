% Evaluates the performance of a solar airplane
% Written by Stefan Leutenegger
% 10/2009
%--------------------------------------------------------------------------
% Input Arguments:
% ================
% climb         1/0, allow climbing
% polar:        Lift/drag coefficients at minimum power point for var. Re
%   .c_L        Lift coefficient list [-]
%   .c_D        Drag coefficient list [-]
%   .ReList:    Reynolds Numbers of c_L / c_D list
% A:            Wing area [m^2]
% m_wo_bat:     airplane empty weight (without battery) [kg]
% bat:          battery characteristics
%   .e_density  energy density [Wh/kg]
%   .m          mass [kg]
%   .n_dchrg    discharge efficiency [-]
%   .n_chrg     charge efficiency [-]
% n_propulsion: propulsion group efficiency [-]
% equiv_area:   equivalent solar area P_elec/Irrandiance [m^2]
% P_0:          constant power draw [W]
% h_0:          nominal altitude not to be superceded [m]
% environment:  environmental conditions 
%   .lat        latitude [deg]
%   .T_ground   temperature on the ground [�K]
%   .day        day of the month
%   .month      month of the year
%   .clearness  clearness of the sky [-]
%   .albedo     earth surface albedo [-]

function [t_excess, t_endurance] = performanceEvaluator2(...
    climb,polar,A,b,m_wo_bat,bat,n_propulsion,equiv_area,P_0,h_0,environment)

% the atmosphere at h_0:
isearth=1;

if(strcmp(environment.planet,'mars'))
    isearth=0;
    g=3.711;
    [rho,mu]=findMarsair(h_0,environment.T_ground);
else
    g  = 9.806; % [m/s^2]
    [rho,mu] = findAir(h_0,environment.T_ground);
end

% Input processing
% ================



% Now simulate the course of a day
% ================================

% Calculate the "Performance" in terms of endurance/range(speed) or 
% excess time, if continuos flight is possible

% Total electric power for level flight at h_0:
v=sqrt(2*(m_wo_bat+bat.m)*g/(rho*A*mean(polar.c_L_cn)));
%refine iteratively
delta_v=1;
while abs(delta_v)>0.01
    Re=min([rho*A/b*v/mu,polar.ReList(length(polar.ReList))]);
    v_old = v;
    CL = interp1(log(polar.ReList),polar.c_L_cn,log(Re));
    v = sqrt((m_wo_bat+bat.m)*g/(0.5*rho*A*CL)); % logarithmic interp.
    delta_v=(v-v_old)/v;
end
CD = interp1(log(polar.ReList),polar.c_D_cn,log(Re));

P_level=1/2*rho*A*CD*v^3;
P_elec_tot = P_0+P_level/n_propulsion;

% find equilibrium
eq_reached=1;
if(isearth==1)
    t0=12*3600;
    ta=t0;
    delta=12*3600;
    irr_vec=solar_radiation_on_surface2(0,0,ta,environment.day,...
        environment.lat,0, h_0,environment.albedo);
    Pa = irr_vec(1)*environment.clearness*equiv_area;
    irr_vec=solar_radiation_on_surface2(0,0,ta+delta,environment.day,...
        environment.lat,0, h_0,environment.albedo);
    Pb = irr_vec(1)*environment.clearness*equiv_area;
else
    eq_reached=1;
    t0=88775/2; %noon!
    ta=t0;
    delta=ta;    
    Pa = irradianceMars([ta-88775/2,environment.Ls,environment.lat])*environment.clearness*equiv_area;
    Pb = irradianceMars([ta+delta-88775/2,environment.Ls,environment.lat])*environment.clearness*equiv_area;
end
if Pb>P_elec_tot
    t_excess=inf;
    t_endurance=inf; % not likely, but needs to be handled
    return;
end
if Pa<P_elec_tot
    eq_reached=0; % not reached
else
    while delta>60
        if(isearth==1)
            irr_vec=solar_radiation_on_surface2(0,0,(ta+tb)/2,environment.day,...
                environment.lat,0, h_0,environment.albedo);
        else
            irr_vec = irradianceMars([(ta+tb)/2-88775/2,environment.Ls,environment.lat]);
        end
        if irr_vec(1)*environment.clearness*equiv_area>P_elec_tot
            ta=(ta+tb)/2;
            delta=delta/2;
        else
            tb=(ta+tb)/2;
            delta=delta/2;
        end
    end
    t1=(ta+tb)/2;
end

E_bat_max = bat.e_density * bat.m * 3600; % maximum battery energy state

% determine battery refilling possibility
if(isreached==1)
t=t0;
delta_t=10*60; % 10 minutes
irr_old=Pa/(environment.clearness*equiv_area);
irr_tot=0;
irr_new=0;
irr_needed=P_elec_tot/(environment.clearness*equiv_area);
if(isearth==1)
    while(irr_old>irr_needed)
        t=t+delta_t;
        irr_new=solar_radiation_on_surface2(0,0,t,environment.day,...
                environment.lat,0, h_0,environment.albedo);
        irr_tot=irr_tot+(irr_old+irr_new(1))/2*delta_t; % trapezoidal integration
        irr_old=irr_new; % memory shift
        if irr_tot>E_bat_max/(environment.clearness*equiv_area);
            break;
        end
    end
else
    while(irr_old>irr_needed)
        t=t+delta_t;
        irr_new=irradianceMars([t-88775/2,environment.Ls,environment.lat]);
        irr_tot=irr_tot+(irr_old+irr_new)/2*delta_t; % trapezoidal integration
        irr_old=irr_new; % memory shift
        if irr_tot>E_bat_max/(environment.clearness*equiv_area);
            break;
        end
    end
end

% this will be available after refilling
E_bat_2=min(E_bat_max,irr_tot*(environment.clearness*equiv_area));


if eq_reached_flag == 1
    % first determine the earliest start time when starting with full batt:
    % (step backward in time)
    E_bat = 0;
    while E_bat < E_bat_max
        if t<0;
            irr = 0; % set zero light before midnight
        else
            irr_vec=solar_radiation_on_surface(0,0,t+seconds,...
                environment.lat,0, h_0,environment.albedo);
            irr = irr_vec(1);
        end
        P_solar = environment.clearness*irr*equiv_area;
        E_bat = E_bat + Dt*(P_elec_tot-P_solar)/bat.n_dchrg;
        t = t - Dt;
    end
    t_start_full = t;
    % now start the simulation with empty battery 
    %--------------------------------------------
    t = t_eq;
    E_bat = 0;
    h=h_0;
    while E_bat >=0 && h>=h_0 && t<3600*24+t_eq
        [rho,mu] = findAir(h,environment.T_ground);
        v=sqrt(2*(m_wo_bat+bat.m)*g/(rho*A*CL));
        %refine iteratively
        delta_v=1;
        while abs(delta_v)>0.01
            Re=min([rho*A/b*v/mu,polar.ReList(length(polar.ReList))]);
            v_old = v;
            CL = interp1(log(polar.ReList),polar.c_L_cn,log(Re));
            v = sqrt((m_wo_bat+bat.m)*g/(0.5*rho*A*CL)); % logarithmic interp.
            delta_v=(v-v_old)/v;
        end
        CD = interp1(log(polar.ReList),polar.c_D_cn,log(Re));
        P_level=1/2*rho*A*CD*v^3;
        P_elec_tot = P_0+P_level/n_propulsion;
        irr_vec=solar_radiation_on_surface(0,0,t+seconds,...
                environment.lat,0, h,environment.albedo);
            irr = irr_vec(1);
        P_solar = environment.clearness*irr*equiv_area;
        
        % optimal control law and state propagation:
        
        if(E_bat>=E_bat_max)
            if(h>h_0)
                E_bat=E_bat_max;
                u=max([0,P_solar-P_elec_tot]);
                delta_E=Dt*(P_solar-u-P_elec_tot);
                if delta_E>0
                    delta_E=delta_E*bat.n_chrg;
                else
                    delta_E=delta_E/bat.n_dchrg;
                end
                h=h+Dt*climb*...
                    (n_propulsion*u-P_level)/((m_wo_bat+bat.m)*g);
                if h<h_0
                    h=h_0;
                end
            else
                E_bat=E_bat_max;
                u=max([P_level/n_propulsion,P_solar-P_elec_tot]);
                delta_E=Dt*(P_solar-u-P_elec_tot);
                if delta_E>0
                    delta_E=delta_E*bat.n_chrg;
                else
                    delta_E=delta_E/bat.n_dchrg;
                end
                h=h+Dt*climb*...
                    (n_propulsion*u-P_level)/((m_wo_bat+bat.m)*g);
            end
        else
            if h>h_0
                u=0;
                delta_E=Dt*(P_solar-u-P_0);
                h=h+Dt*climb*...
                    (n_propulsion*u-P_level)/((m_wo_bat+bat.m)*g);
                if(h<h_0) 
                    h=h_0; 
                end
            else
                u=P_level/n_propulsion;
                h=h_0;
                delta_E=Dt*(P_solar-u-P_0);
            end
            if delta_E>0
                delta_E=delta_E*bat.n_chrg;
            else
                delta_E=delta_E/bat.n_dchrg;
            end
        end
        E_bat=E_bat+delta_E;
        t = t + Dt;
        t_array=[t_array,t];
        h_array=[h_array,h];
        bat_array=[bat_array,E_bat];
        irr_array=[irr_array,irr];
%         subplot(3,1,1);
%         plot(t./3600,h,'o');
%         ylabel('Height [m]');
%         hold on;
%         subplot(3,1,2);
%         plot(t./3600,E_bat,'o');
%         ylabel('Battery Energy [J]');
%         hold on;
%         subplot(3,1,3);
%         plot(t./3600,irr,'o');
%         ylabel('irradiance [W/m\^2]');
%         xlabel('Time of Day [h]');
%         hold on;
    end
    t_end = t;
else % if the equilibrium is never reached:
    E_bat = E_bat_max/2; % symmetry assumption for the discharge
    t=12*3600; % symmetry assumption for the discharge
    while E_bat >= 0
        irr_vec=solar_radiation_on_surface(0,0,t+seconds,...
            environment.lat,0, h_0,environment.albedo);
        irr = irr_vec(1);
        P_solar = environment.clearness*irr*equiv_area;
        delta_E = Dt*(P_solar-P_elec_tot)/bat.n_dchrg;
        E_bat = E_bat + delta_E;
        t = t + Dt;
    end
    t_end = t;
    t_start_full = 24*3600-t;
end

% Output Calculation
% ==================

if eq_reached_flag == 1
    t_excess = bat.n_dchrg*E_bat/P_elec_tot/3600;
else
    t_excess = NaN;
end
t_endurance = (t_end-t_start_full)/3600;
if t_excess > 0
    t_endurance = NaN; % the term endurance non-existent
else
    t_excess = NaN;
end
subplot(3,1,1);
plot(t_array/3600,h_array/1000);
ylabel('Height [km]');
subplot(3,1,2);
plot(t_array/3600,bat_array/1e6);
ylabel('Battery Energy [MJ]');
subplot(3,1,3);
plot(t_array/3600,irr_array/1000);
ylabel('Irradiance [kW/m^2]');
xlabel('Time of Day [h]');