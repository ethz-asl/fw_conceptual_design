function minus_h=evaluateSolutionSearch(in)
b=in(1);
AR=in(2);
m_bat=in(3);
disp(in);

initParameters;

% Editable Section:
% =================

global environment;

% Set environment, payload and airfoil
environment.month = 6;
environment.day = 21;
environment.h = 700;
environment.T_ground = 300;
%%environment.lat = 47;
environment.albedo = 0.2;
environment.clearness = 1;
payload.mass = 0.6;%0.2;%0.722;
payload.power = 4;%1.7;%18.4;

% Change some parameters
parameters.propulsion.number  =  2;        % Number of propulsion units [-]
parameters.structure.shell    =  0;        % 1 for shell wing, 0 for rib wing
parameters.evaluation.clmb    =  0;        % 1 to allow altitude changes
parameters.evaluation.findalt =  1;        % if 1, it finds the maximum
                                           % altitude for eternal flight

%--------------------------------------------------------------


[performance,polar,masses] = ...
evaluateSolution(b,AR,m_bat,payload,environment,parameters);

minus_h=-performance.h;