% variable time and latitude

%% specify:
b=5.4;
AR=21;
m_bat=4;
lat_array=0:10:50;
days=365;
day_array=5*30.5+21-days/2:1:5*30.5+21+days/2;


%% calc
m_solar = b*b/AR*...
    (parameters.solar.k_sc+parameters.solar.k_enc);

% MPPT
I_max = 1200; %[W/m^2]
m_mppt = parameters.solar.k_mppt*I_max*b*b/AR ...
	*parameters.solar.n_sc*parameters.solar.n_cbr;

% total point mass
m_central = m_mppt+payload.mass+parameters.avionics.mass...
    +(1-parameters.batt.distr)*m_bat;

% total distributed mass
m_distr = m_solar+m_bat*parameters.batt.distr;


% Automatic Preliminary Design (S. Leutenegger / M. Jabas)
% ========================================================
if(parameters.structure.shell==1)
    [m_struct,masses,thicknesses,velocities,polar]=StructureDesigner(b,AR,...
        m_central,m_distr,parameters.propulsion.number,environment.usemars);
else
    [m_struct,masses,thicknesses,velocities,polar]=StructureDesignerRibWing(b,AR,...
        m_central,m_distr,parameters.propulsion.number,environment.usemars);
end
masses.m_struct=m_struct;

% Now simulate the course of a day
% ================================

% Calculate the "Performance" in terms of endurance/range(speed) or 
% excess time, if continuos flight is possible

batt.e_density=parameters.batt.k_bat/3600;
batt.m=m_bat;
batt.n_chrg=parameters.batt.n_chrg;
batt.n_dchrg=parameters.batt.n_dchrg;


%% vary season and lat
excMat=zeros(length(lat_array),length(day_array));
i=1;
for lat=lat_array
    j=1;
    for day=day_array
        
        environment.dayofyear = day;
        environment.lat = lat;
        
        [performance.t_excess, performance.t_endurance] = performanceEvaluator_new(...
                parameters.evaluation.clmb,polar,b^2/AR,b,...
                masses.m_prop+m_distr+m_central+m_struct-m_bat,batt,...
                parameters.propulsion.n_ctrl*parameters.propulsion.n_mot...
                *parameters.propulsion.n_grb*parameters.propulsion.n_plr,...
                parameters.solar.n_sc*parameters.solar.n_cbr...
                *parameters.solar.n_mppt*b^2/AR,...
                payload.power+parameters.avionics.power,environment.h,environment);
    
        excMat(i,j)=performance.t_excess;
    
        j=j+1;
    end
    i=i+1;
end

%% plotting
[c2,hc2]=contourf(day_array,...
    lat_array, excMat,...
    200,'Linestyle','none');
xlabel('Day of the year')
ylabel('Latitude [�N]');
title('Excess Time [h]');
caxis([-6,6])


nc = get(hc2,'Children');
    temp = 100;
    select_i=zeros(length(nc),1);
    for i = 1:length(nc)
       ud1 = get(nc(i),'UserData');   
       if (abs(ud1) < temp)
           temp = abs(ud1);
       end
    end
    filler=1;
    for i = 1:length(nc)
       ud1 = get(nc(i),'UserData');   
       if (abs(ud1) == temp)
           select_i(filler)=i;
           filler=filler+1;
       end
    end
    j=1;
    if i>0
        while(select_i(j)~=0)
            set(nc(select_i(j)),'Linestyle','-');
            set(nc(select_i(j)),'LineWidth',2);
            j=j+1;
        end
    end

colorbar