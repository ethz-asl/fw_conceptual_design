%==========================================================================
%=== Analyze the the Design Space of the senseSoar Airplane
%=== Stefan Leutenegger
%=== 05/2009
%==========================================================================

% Initialize
clear variables;
close all;
clc;
% use double core- processing
% matlabpool open 2
% options = optimset('UseParallel','always');
initParameters;

% Editable Section:
% =================

% Set the discretization
b_min      = 12;
b_max      = 28;
b_step     = 0.2;
m_bat_min  = 2;
m_bat_max  = 20;
m_bat_step = 0.2;
AR_min     = 12;
AR_max     = 12;
AR_step    = 1;

% Set environment, payload and airfoil
environment.month = 6;
environment.day = 21;
environment.dayofyear = 6*30.5+21;
environment.h = 100;
environment.T_ground = 240;
environment.lat = -45;
environment.Ls=256;
environment.albedo = 0.2;
environment.clearness = 1;
environment.usemars = 1;
payload.mass = 0.62;%0.2;%0.722;
payload.power = 7;%1.7;%18.4;

% Change some parameters
parameters.propulsion.number  =  2;        % Number of propulsion units [-]
parameters.structure.shell    =  0;        % 1 for shell wing, 0 for rib wing
parameters.evaluation.clmb    =  1;        % 1 to allow altitude changes
parameters.evaluation.findalt =  0;        % if 1, it finds the maximum
                                           % altitude for eternal flight

parameters.batt.k_bat=240*3600; % Mars necessary energy density of LiIon [J/Kg]                                           
%parameters.solar.n_sc=0.34; % Mars necessary solar cell eff. [J/Kg]
%parameters.solar.k_sc=0.5;
                                        
%--------------------------------------------------------------

% Evaluation
% ==========

% Number of configurations calculated:
N = ((b_max-b_min)/b_step+1)...
    *((m_bat_max-m_bat_min)/m_bat_step+1)...
    *((AR_max-AR_min)/AR_step+1);
%disp(['Number of configurations to be calculated: ' num2str(N)])
%disp(['Expected processing time: ' num2str(N*10/3600) ' h'])

% Start the evaluation
h=waitbar(0,'Progress');
i=0;
tic
l=0;
%data storage matrices (3D)
AR_array=AR_min:AR_step:AR_max;
b_array=b_min:b_step:b_max;
m_bat_array=m_bat_min:m_bat_step:m_bat_max;
t_excess=zeros(length(b_array),length(m_bat_array),length(AR_array));
t_endurance=zeros(length(b_array),length(m_bat_array),length(AR_array));
continuousflight=zeros(length(b_array),length(m_bat_array),length(AR_array));
v_tmax=zeros(length(b_array),length(m_bat_array),length(AR_array));
m_struct=zeros(length(b_array),length(m_bat_array),length(AR_array));
for AR=AR_array
    l=l+1;
    m=0;
    for b=b_array
        m=m+1;
        n=0;
        for m_bat=m_bat_array
            n=n+1;
            [performance,polar,masses] = ...
               evaluateSolution(b,AR,m_bat,payload,environment,parameters);
            % store
            t_excess(m,n,l)=performance.t_excess;
            t_endurance(m,n,l)=performance.t_endurance;
            %continuousflight(m,n,l)=performance.continuousflight;
            v_tmax(m,n,l)=performance.v_tmax;
            m_struct(m,n,l)=masses.m_struct;
            % waiting times
            i=i+1;
            
            elapsed = toc;
%             clc
            remaining = N*elapsed/i-elapsed;
            rhours=floor(remaining/3600);
            rminutes=floor((remaining-rhours*3600)/60);
            rseconds=floor((remaining-rhours*3600-rminutes*60));
            %disp(['Time remaining: ' num2str(rhours,'%02.0f') ':' ...
            %    num2str(rminutes,'%02.0f') ':' num2str(rseconds,'%02.0f')]);
            waitbar(i/N,h,['Time remaining: ' num2str(rhours,'%02.0f') ':' ...
                num2str(rminutes,'%02.0f') ':' num2str(rseconds,'%02.0f')]);
        end
    end
end
close(h)

%Plotting
l=1;
for AR=AR_min:AR_step:AR_max
    figure
    
    subplot(2,2,1)
    [c2,hc2]=contourf(b_min:b_step:b_max,...
        m_bat_min:m_bat_step:m_bat_max, t_excess(:,:,l)',...
        200,'Linestyle','none');
    xlabel('Wingspan (b) [m]')
    ylabel('Battery mass (m\_bat) [kg]');
    title(['Excess Time [h] (AR=' num2str(AR) ')']);
    caxis([-15,15])
    colorbar
    
    nc = get(hc2,'Children');
    temp = 100;
    select_i=zeros(length(nc),1);
    for i = 1:length(nc)
       ud1 = get(nc(i),'UserData');   
       if (abs(ud1) < temp)
           temp = abs(ud1);
       end
    end
    filler=1;
    for i = 1:length(nc)
       ud1 = get(nc(i),'UserData');   
       if (abs(ud1) == temp)
           select_i(filler)=i;
           filler=filler+1;
       end
    end
    j=1;
    if i>0
        while(select_i(j)~=0)
            set(nc(select_i(j)),'Linestyle','-');
            set(nc(select_i(j)),'LineWidth',2);
            j=j+1;
        end
    end

    
    subplot(2,2,2)
    contourf(b_min:b_step:b_max,...
        m_bat_min:m_bat_step:m_bat_max, t_endurance(:,:,l)',...
        200,'Linestyle','none');
    xlabel('Wingspan (b) [m]')
    ylabel('Battery mass (m\_bat) [kg]');
    title(['Endurance [h] (AR=' num2str(AR) ')']);
    caxis([0,48])
    colorbar
    
    subplot(2,2,3)
    contourf(b_min:b_step:b_max,...
        m_bat_min:m_bat_step:m_bat_max, v_tmax(:,:,l)',...
        200,'Linestyle','none');
    xlabel('Wingspan (b) [m]')
    ylabel('Battery mass (m\_bat) [kg]');    
    title(['Nominal Speed [m/s] (AR=' num2str(AR) ')']);
    caxis([min(min( v_tmax(:,:,l))),max(max( v_tmax(:,:,l)))])
    colorbar
    
    subplot(2,2,4)
    contourf(b_min:b_step:b_max,...
        m_bat_min:m_bat_step:m_bat_max, m_struct(:,:,l)',200,...
        'Linestyle','none');
    xlabel('Wingspan (b) [m]')
    ylabel('Battery mass (m\_bat) [kg]');
    title(['Structural Mass [kg] (AR=' num2str(AR) ')']);
    caxis([min(min( m_struct(:,:,l))),max(max(m_struct(:,:,l)))])
    colorbar
    
    l=l+1;
end
%end use double core- processing
% matlabpool close
