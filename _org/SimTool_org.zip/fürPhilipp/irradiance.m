function out=irradiance(in)

%[1] http://ccar.colorado.edu/asen5050/projects/projects_2001/benoit/solar_irra
%    diance_on_mars.htm
%[2] Applebaum

time            =   in(1);
orientation     =   in(2);
slope           =   in(3);
latitude        =   in(4);
longitude       =   in(5);
altitude        =   in(6);
albedo          =   in(7);

r=solar_radiation_on_surface(slope, orientation,time,latitude,longitude, altitude,albedo);
computed_irradiance=r(1);
computed_azimut_angle=r(8)*180/pi;
computed_zenith_angle=r(9)*180/pi;

out(1)          =   r(1);       % Computed_irradiance
out(2)          =   r(2);       % Computed_azimut_angle
out(3)          =   r(3);       % Computed_zenith_angle